<?php
mysql_connect("localhost","patient","afolasade111") or die (mysql_error());
?>